package com.example.linebotpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinebotPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinebotPracticeApplication.class, args);
	}

}
