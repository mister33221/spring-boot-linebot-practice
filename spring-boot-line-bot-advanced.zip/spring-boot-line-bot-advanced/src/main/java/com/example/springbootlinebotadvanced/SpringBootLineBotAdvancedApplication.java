package com.example.springbootlinebotadvanced;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLineBotAdvancedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLineBotAdvancedApplication.class, args);
	}

}
