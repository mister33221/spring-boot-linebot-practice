package com.example.springbootlinebotadvanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLineBotAdvancedApplicationTests {

	@Test
	void contextLoads() {
	}

}
