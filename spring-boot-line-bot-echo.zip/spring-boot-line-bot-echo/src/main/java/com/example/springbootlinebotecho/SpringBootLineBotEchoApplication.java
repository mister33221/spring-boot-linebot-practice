package com.example.springbootlinebotecho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLineBotEchoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLineBotEchoApplication.class, args);
	}

}
